let app = new angular.module('vizsgaApp', ['ngRoute']);

app.run(function($rootScope) {
    $rootScope=[
    app.title="Jegyfoglalo App",
    app.author="Korsós Ádám",
    app.Company="Bajai SZC Türr István Technikum",
    app.currency="Ft"]

});

app.config(function($routeProvider) {  
$routeProvider.when("/koncertek",{
    templateUrl:'views/koncertek.html',
    controller:'koncertCtrl.js'
})
.when("/fellepok",{
    templateUrl:'views/fellepok.html',
    controller:'fellepoCtrl.js'
    })
.when("/jegyek",{
    templateUrl:'views/jegyvasarlas.html',
    controller:'jegyCtrl.js'
    })

});