app.controller('fellepoCtrl', function($scope, DB) {

var fellepok = $scope=[
    DB.
]
})