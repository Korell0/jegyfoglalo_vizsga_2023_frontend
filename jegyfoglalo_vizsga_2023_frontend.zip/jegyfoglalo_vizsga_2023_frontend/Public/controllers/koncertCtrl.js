app.controller('koncertCtrl', function($scope, DB) {

});