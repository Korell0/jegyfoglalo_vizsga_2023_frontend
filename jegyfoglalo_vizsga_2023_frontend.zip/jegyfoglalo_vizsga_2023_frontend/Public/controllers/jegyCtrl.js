app.controller('jegyCtrl', function($scope, DB) {

});