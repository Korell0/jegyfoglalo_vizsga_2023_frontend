<?php
    echo " Simple PHP Backend API";
?>